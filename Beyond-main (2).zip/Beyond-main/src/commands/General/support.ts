import { MessageType, Mimetype } from "@adiwajshing/baileys";
import MessageHandler from "../../Handlers/MessageHandler";
import BaseCommand from "../../lib/BaseCommand";
import WAClient from "../../lib/WAClient";
import { ISimplifiedMessage } from "../../typings";

export default class Command extends BaseCommand {
  constructor(client: WAClient, handler: MessageHandler) {
    super(client, handler, {
      command: "support",
      aliases: ["support"],
      description: "Gets the support group links",
      category: "general",
      usage: `${client.config.prefix}Support`,
      baseXp: 10,
    });
  }

  run = async (M: ISimplifiedMessage): Promise<void> => {
    await this.client.sendMessage(
      M.sender.jid,
`┌──❁┈[ 🎋N̸e̸z̸u̸k̸o̸ᵇᵒᵗ🎋 ]┈❁────
├➸ Author :☞ 🎋N̸e̸z̸u̸k̸o̸🎋
├➸ Build With :☞ Linux server
├➸ 0.) BOT PREFIX  (:)
├────❁┈[ RULES ]┈❁─────
├➸ 1.) PORN NOT ALLOWED.
├➸ 2.) SEND LINK IN PM FOR JOIN THE BOT
├➸ 3.) NO FIGHTING BE FRIENDLY.
├➸ 4.) ENGLISH ONLY.
├➸ 5.) RESPECT ADMINS!
├➸ 6.) DON'T PM ADMINS
├➸ 7.) LINKS AREN'T ALLOWED
├────❁┈[ 🎋N̸e̸z̸u̸k̸o̸ᵇᵒᵗ🎋 ]┈❁─────
│HERE YOU CAN ASK ANY QUESTIONS.
│RELATED TO ASTRO BOT,
│& HOW TO INVITE BOT IN GROUP'S.
├──────────────────────❁
│   ©️ 🎋N̸e̸z̸u̸k̸o̸ᵇᵒᵗ🎋234 ID
└──────────────────────❁

01. 🎋N̸e̸z̸u̸k̸o̸ᵇᵒᵗ S̸u̸p̸p̸o̸r̸t̸🎋 ©
https://chat.whatsapp.com/HpkkC27qTrA6SXLrsQhDPg

❁┈[ We Hope-You've A Great-Time ]┈❁`,

      MessageType.text
    );

    return void M.reply("Check your inbox📬");
  };
}
